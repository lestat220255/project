<?php

/**
 * stub class representing AMQPQueueException from pecl-amqp
 */
class AMQPQueueException extends AMQPException
{
}
